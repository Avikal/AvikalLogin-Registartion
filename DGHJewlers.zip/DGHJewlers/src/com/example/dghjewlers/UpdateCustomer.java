package com.example.dghjewlers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.dghjewlers.model.DataBaseHelper;

public class UpdateCustomer extends Activity {
	
	int REQUEST_CAMERA = 0, SELECT_FILE = 1;
	private static final int CAMERA_REQUEST = 1;
	private static final int PICK_FROM_GALLERY = 2;
	byte[] imageInByte;
	ImageView cust_image;

	String str_name, str_father, str_date, str_address, str_village,
			str_mobile, str_amount, str_itemType, str_weight, str_description;
	Button update_customer;
//	byte[] image;
	Bundle bundle;
	int cust_id;
	EditText full_name, father_name, register_date, register_address,
	register_Village, register_phone, register_Amount, register_Item,
	register_weight, register_descrption;
	ImageView user_picture, user_picture1;
	DataBaseHelper dataBase;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.update_customer);
		bundle = getIntent().getExtras();
		dataBase = new DataBaseHelper(getApplicationContext());
		
		update_customer = (Button) findViewById(R.id.update_cust);
		cust_id = bundle.getInt("custId");
		str_name = bundle.getString("custFullName");
		str_father = bundle.getString("custFatherName");
		str_date = bundle.getString("custDate");
		str_address = bundle.getString("custAddress");
		str_village = bundle.getString("custVillage");
		str_mobile = bundle.getString("custMobile");
		str_amount = bundle.getString("custAmount");
		str_itemType = bundle.getString("custItemType");
		str_weight = bundle.getString("custWeight");
		str_description = bundle.getString("custDesription");
		imageInByte = bundle.getByteArray("custImage");
		full_name = (EditText) findViewById(R.id.editTextfullname);
		father_name = (EditText) findViewById(R.id.editTextRegisterFat_name);
		register_date = (EditText) findViewById(R.id.editTextRegisterDate);
		register_address = (EditText) findViewById(R.id.editTextRegisterAddress);
		register_Village = (EditText) findViewById(R.id.editTextRegisterVillage);
		register_phone = (EditText) findViewById(R.id.editTextRegisterPhone);
		register_Amount = (EditText) findViewById(R.id.editTextRegisterAmount);
		register_Item = (EditText) findViewById(R.id.editTextRegisterItemType);
		register_weight = (EditText) findViewById(R.id.editTextRegisterWeight);
		register_descrption = (EditText) findViewById(R.id.editTextRegisterDescribe);
//		user_picture = (ImageView) findViewById(R.id.user_pic);
		user_picture1 = (ImageView) findViewById(R.id.cust_picture);
		
		full_name.setText(str_name);
		father_name.setText(str_father);
		register_date.setText(str_date);
		register_address.setText(str_address);
		register_Village.setText(str_village);
		register_phone.setText(str_mobile);
		register_Amount.setText(str_amount);
		register_Item.setText(str_itemType);
		register_weight.setText(str_weight);
		register_descrption.setText(str_description);

		ByteArrayInputStream imageStream = new ByteArrayInputStream(imageInByte);
		Bitmap theImage = BitmapFactory.decodeStream(imageStream);
		
		user_picture1.setImageBitmap(theImage);
		final String[] option = new String[] { "Take from Camera",
				"Select from Gallery" };
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.select_dialog_item, option);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		builder.setTitle("Select Option");
		builder.setAdapter(adapter, new DialogInterface.OnClickListener() {

			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Log.e("Selected Item", String.valueOf(which));
				if (which == 0) {
					callCamera();
				}
				if (which == 1) {
					callGallery();
				}

			}
		});
		final AlertDialog dialog = builder.create();

		user_picture1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				dialog.show();
			}
		});
		
		update_customer.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				str_name = full_name.getText().toString();
				str_father = father_name.getText().toString();
				str_date = register_date.getText().toString();
				str_address = register_address.getText().toString();
				str_village = register_Village.getText().toString();
				str_mobile = register_phone.getText().toString();
				str_amount = register_Amount.getText().toString();
				str_itemType = register_Item.getText().toString();
				str_weight = register_weight.getText().toString();
				str_description = register_descrption.getText().toString();
				long d = dataBase.updateCustomer(cust_id,str_name, str_father, str_date, str_address, str_village,
						str_mobile, str_amount, str_itemType, str_weight, str_description,imageInByte);
				
				if(d>0)
				{
					Toast.makeText(getApplicationContext(), "Successfull Update", 5000).show();
				}
				Intent delete = new Intent(UpdateCustomer.this,ViewCustomer.class);
				startActivity(delete);
				finish();

			}
		});
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK)
			return;

		switch (requestCode) {
		case CAMERA_REQUEST:

			Bundle extras = data.getExtras();

			if (extras != null) {
				Bitmap yourImage = extras.getParcelable("data");
				// convert bitmap to byte
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				yourImage.compress(Bitmap.CompressFormat.PNG, 100, stream);
				imageInByte = stream.toByteArray();

//				image_str = Base64.encodeBytes(imageInByte);
//
//				imageInByte1 = imageInByte;
				Log.e("output before conversion", imageInByte.toString());
				// Inserting Contacts
				Log.d("Insert: ", "Inserting ..");
				user_picture1.setImageBitmap(yourImage);
//				user_picture.setVisibility(View.GONE);
				user_picture1.setVisibility(View.VISIBLE);
				// db.addContact(new Contact(resultCode, "Android",
				// imageInByte));
				// Intent i = new Intent(CmplainActivity.this,
				// CmplainActivity.class);
				// startActivity(i);
				// finish();

			}
			break;
		case PICK_FROM_GALLERY:
			Bundle extras2 = data.getExtras();

			if (extras2 != null) {
				Bitmap yourImage = extras2.getParcelable("data");
				// convert bitmap to byte
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				yourImage.compress(Bitmap.CompressFormat.PNG, 100, stream);
				imageInByte = stream.toByteArray();
//				image_str = Base64.encodeBytes(imageInByte);

				Log.e("output before conversion", imageInByte.toString());
				// Inserting Contacts
				Log.d("Insert: ", "Inserting ..");

				
				user_picture1.setImageBitmap(yourImage);
//				user_picture.setVisibility(View.GONE);
				user_picture1.setVisibility(View.VISIBLE);
//				imageInByte1 = imageInByte;
				// db.addContact(new Contact(resultCode, "Android",
				// imageInByte));
				// Intent i = new Intent(CmplainActivity.this,
				// CmplainActivity.class);
				// startActivity(i);
				// finish();
			}

			break;
		}
	}
	public void callCamera() {
		Intent cameraIntent = new Intent(
				android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
		cameraIntent.putExtra("crop", "true");
		cameraIntent.putExtra("aspectX", 0);
		cameraIntent.putExtra("aspectY", 0);
		cameraIntent.putExtra("outputX", 200);
		cameraIntent.putExtra("outputY", 150);
		startActivityForResult(cameraIntent, CAMERA_REQUEST);

	}

	/**
	 * open gallery method
	 */

	public void callGallery() {
		Intent intent = new Intent();
		intent.setType("image/*");
		intent.setAction(Intent.ACTION_GET_CONTENT);
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 0);
		intent.putExtra("aspectY", 0);
		intent.putExtra("outputX", 200);
		intent.putExtra("outputY", 150);
		intent.putExtra("return-data", true);
		startActivityForResult(
				Intent.createChooser(intent, "Complete action using"),
				PICK_FROM_GALLERY);

	}

}
