package com.example.dghjewlers;

import java.io.ByteArrayOutputStream;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dghjewlers.model.DataBaseHelper;
import com.example.dghjewlers.model.SessionManager;

public class AddCustomer extends Activity {
	int REQUEST_CAMERA = 0, SELECT_FILE = 1;
	private static final int CAMERA_REQUEST = 1;
	private static final int PICK_FROM_GALLERY = 2;
	EditText full_name, father_name, register_date, register_address,
			register_Village, register_phone, register_Amount, register_Item,
			register_weight, register_descrption;
	String cust_name, cust_fatname, cust_date, cust_address, cust_village,
			cust_phone, cust_amount, cust_item, cust_weight, cust_descrption;
	Button add_customerButton, view_customerButton;
	String selectedImagePath;
	ImageView nav_back;
	ImageView user_picture, user_picture1;
	byte[] imageInByte;
	DataBaseHelper dataBase;
	SessionManager session;
	TextView logout;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cust_register_xml);

		dataBase = new DataBaseHelper(getApplicationContext());
		session = new SessionManager(getApplicationContext());
		if (!session.isLoggedIn()) {
			logoutUser();
		}
		logout = (TextView) findViewById(R.id.text_logout);
		full_name = (EditText) findViewById(R.id.editTextfullname);
		father_name = (EditText) findViewById(R.id.editTextRegisterFat_name);
		register_date = (EditText) findViewById(R.id.editTextRegisterDate);
		register_address = (EditText) findViewById(R.id.editTextRegisterAddress);
		register_Village = (EditText) findViewById(R.id.editTextRegisterVillage);
		register_phone = (EditText) findViewById(R.id.editTextRegisterPhone);
		register_Amount = (EditText) findViewById(R.id.editTextRegisterAmount);
		register_Item = (EditText) findViewById(R.id.editTextRegisterItemType);
		register_weight = (EditText) findViewById(R.id.editTextRegisterWeight);
		register_descrption = (EditText) findViewById(R.id.editTextRegisterDescribe);
		user_picture = (ImageView) findViewById(R.id.user_pic);
		user_picture1 = (ImageView) findViewById(R.id.user_picture);
		
		add_customerButton = (Button) findViewById(R.id.user_Submit);
		view_customerButton = (Button) findViewById(R.id.user_view);
		
		logout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				logoutUser();
			}
		});
		final String[] option = new String[] { "Take from Camera",
				"Select from Gallery" };
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.select_dialog_item, option);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		builder.setTitle("Select Option");
		builder.setAdapter(adapter, new DialogInterface.OnClickListener() {

			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Log.e("Selected Item", String.valueOf(which));
				if (which == 0) {
					callCamera();
				}
				if (which == 1) {
					callGallery();
				}

			}
		});
		final AlertDialog dialog = builder.create();

		user_picture.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				dialog.show();
			}
		});
		
		add_customerButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(cust_name!=null&&cust_fatname!=null&&cust_date!=null&&cust_address!=null&&cust_village!=null&&cust_phone!=null
						&&cust_amount!=null&&cust_item!=null&&cust_weight!=null&&cust_descrption!=null
						&&imageInByte!=null)
				{
				cust_name = full_name.getText().toString();
				cust_fatname = father_name.getText().toString();
				cust_date = register_date.getText().toString();
				cust_address = register_address.getText().toString();
				cust_village = register_Village.getText().toString();
				cust_phone = register_phone.getText().toString();
				cust_amount = register_Amount.getText().toString();
				cust_item = register_Item.getText().toString();
				cust_weight = register_weight.getText().toString();
				cust_descrption = register_descrption.getText().toString();
				
				dataBase.addUser(cust_name, cust_fatname, cust_date, cust_address, cust_village, cust_phone, cust_amount, cust_item, cust_weight, cust_descrption,imageInByte);
				Toast.makeText(getApplicationContext(), "Customer Succefull Added", Toast.LENGTH_SHORT).show();
				Reset_Text();
				}
				else
				{
					Toast.makeText(getApplicationContext(), "All Field Required", Toast.LENGTH_SHORT).show();

				}
			}
		});
		
		view_customerButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent view_customer = new Intent(AddCustomer.this,ViewCustomer.class);
				startActivity(view_customer);
				finish();
			}
		});

	}
	public void logoutUser() {
		session.setLogin(false);

		dataBase.resetTables();

		Intent intent = new Intent(AddCustomer.this, LoginActivity.class);
		startActivity(intent);
		finish();

	}
	public void Reset_Text()
	{
		full_name.getText().clear();
		father_name.getText().clear();
		register_date.getText().clear();
		register_address.getText().clear();
		register_Village.getText().clear();
		register_phone.getText().clear();
		register_Amount.getText().clear();
		register_Item.getText().clear();
		register_weight.getText().clear();
		register_descrption.getText().clear();
		
		user_picture.setVisibility(View.VISIBLE);
		user_picture1.setVisibility(View.GONE);
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK)
			return;

		switch (requestCode) {
		case CAMERA_REQUEST:

			Bundle extras = data.getExtras();

			if (extras != null) {
				Bitmap yourImage = extras.getParcelable("data");
				// convert bitmap to byte
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				yourImage.compress(Bitmap.CompressFormat.PNG, 100, stream);
				imageInByte = stream.toByteArray();

//				image_str = Base64.encodeBytes(imageInByte);
//
//				imageInByte1 = imageInByte;
				Log.e("output before conversion", imageInByte.toString());
				// Inserting Contacts
				Log.d("Insert: ", "Inserting ..");
				user_picture1.setImageBitmap(yourImage);
				user_picture.setVisibility(View.GONE);
				user_picture1.setVisibility(View.VISIBLE);
				// db.addContact(new Contact(resultCode, "Android",
				// imageInByte));
				// Intent i = new Intent(CmplainActivity.this,
				// CmplainActivity.class);
				// startActivity(i);
				// finish();

			}
			break;
		case PICK_FROM_GALLERY:
			Bundle extras2 = data.getExtras();

			if (extras2 != null) {
				Bitmap yourImage = extras2.getParcelable("data");
				// convert bitmap to byte
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				yourImage.compress(Bitmap.CompressFormat.PNG, 100, stream);
				imageInByte = stream.toByteArray();
//				image_str = Base64.encodeBytes(imageInByte);

				Log.e("output before conversion", imageInByte.toString());
				// Inserting Contacts
				Log.d("Insert: ", "Inserting ..");

				
				user_picture1.setImageBitmap(yourImage);
				user_picture.setVisibility(View.GONE);
				user_picture1.setVisibility(View.VISIBLE);
//				imageInByte1 = imageInByte;
				// db.addContact(new Contact(resultCode, "Android",
				// imageInByte));
				// Intent i = new Intent(CmplainActivity.this,
				// CmplainActivity.class);
				// startActivity(i);
				// finish();
			}

			break;
		}
	}
	public void callCamera() {
		Intent cameraIntent = new Intent(
				android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
		cameraIntent.putExtra("crop", "true");
		cameraIntent.putExtra("aspectX", 0);
		cameraIntent.putExtra("aspectY", 0);
		cameraIntent.putExtra("outputX", 200);
		cameraIntent.putExtra("outputY", 150);
		startActivityForResult(cameraIntent, CAMERA_REQUEST);

	}

	/**
	 * open gallery method
	 */

	public void callGallery() {
		Intent intent = new Intent();
		intent.setType("image/*");
		intent.setAction(Intent.ACTION_GET_CONTENT);
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 0);
		intent.putExtra("aspectY", 0);
		intent.putExtra("outputX", 200);
		intent.putExtra("outputY", 150);
		intent.putExtra("return-data", true);
		startActivityForResult(
				Intent.createChooser(intent, "Complete action using"),
				PICK_FROM_GALLERY);

	}

}
