package com.example.dghjewlers.model;

public class SetGetMethod {

	int id;
	
	int cust_id;
	String cust_fullname;
	String cust_fathername;
	String cust_date;
	String cust_address;
	String cust_village;
	String cust_mobile;
	String cust_amount;
	String cust_itemType;
	String cust_wieght;
	String cust_desription;
	public byte [] cust_image;
	
	
	public SetGetMethod()
	{
		
	}
	
	public SetGetMethod(int cust_id, String cust_fullname, String cust_fathername, String cust_date,
			String cust_address,String cust_village,String cust_mobile,String cust_amount,String cust_itemType,
			String cust_wieght,String cust_desription, byte[] cust_image)
	{
		this.cust_id =  cust_id;
		this.cust_fullname = cust_fullname;
		this.cust_fathername = cust_fathername;
		this.cust_date = cust_date;
		this.cust_address = cust_address;
		this.cust_village = cust_village;
		this.cust_mobile = cust_mobile;
		this.cust_amount = cust_amount;
		this.cust_itemType = cust_itemType;
		this.cust_wieght = cust_wieght;
		this.cust_desription = cust_desription;
		this.cust_image = cust_image;
	}
	
	public int getId()
	{
		return cust_id;
	}
	public void setId(int cust_id)
	{
		this.cust_id = cust_id;
	}
	
	public String getFullName()
	{
		return cust_fullname;
	}
	public void setFullName(String cust_fullname)
	{
		this.cust_fullname = cust_fullname;
	}
	
	public String getFatherName()
	{
		return cust_fathername;
	}
	public void setFatherName(String cust_fathername)
	{
		this.cust_fathername = cust_fathername;
	}
	
	public String getDate()
	{
		return cust_date;
	}
	public void setDate(String cust_date)
	{
		this.cust_date = cust_date;
	}
	
	public String getAddress()
	{
		return cust_address;
	}
	public void setAddress(String cust_address)
	{
		this.cust_address = cust_address;
	}
	
	public String getVillage()
	{
		return cust_village;
	}
	public void setVillage(String cust_village)
	{
		this.cust_village = cust_village;
	}
	
	public String getMobile()
	{
		return cust_mobile;
	}
	public void setMobile(String cust_mobile)
	{
		this.cust_mobile = cust_mobile;
	}
	
	public String getAmount()
	{
		return cust_amount;
	}
	public void setAmount(String cust_amount)
	{
		this.cust_amount = cust_amount;
	}
	
	public String getitemType()
	{
		return cust_itemType;
	}
	public void setitemType(String cust_itemType)
	{
		this.cust_itemType = cust_itemType;
	}
	
	public String getWeight()
	{
		return cust_wieght;
	}
	public void setWeight(String cust_wieght)
	{
		this.cust_wieght = cust_wieght;
	}
	public String getDesription()
	{
		return cust_desription;
	}
	public void setDescription(String cust_desription)
	{
		this.cust_desription = cust_desription;
	}
	
	public byte[] getImage()
	{
		return cust_image;
	}
	public void setImage(byte[] cust_image)
	{
		this.cust_image = cust_image;
	}
}
