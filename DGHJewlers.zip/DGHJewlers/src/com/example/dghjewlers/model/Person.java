package com.example.dghjewlers.model;

public class Person 
{
	String userName,phoneNo,email, /*newEmail ,*/pass;
	
	public Person(String userName, String phoneNo, String email, /*String newEmail,*/ String pass)
	{
		super();
		this.userName = userName;
		this.phoneNo = phoneNo;
		this.email = email;
//		this.newEmail = newEmail;
		this.pass = pass;
	}

	
	public String getUsername() {
		return userName;
	}

	public void setUsername(String userName) {
		this.userName = userName;
	}
	
	public String getPhoneNo()
	{
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo)
	{
		this.phoneNo = phoneNo;
	}
	
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	
	/*public String getNewEmail()
	{
		return newEmail;
	}
	public void setNewEmail(String newEmail)
	{
		this.newEmail = newEmail;
	}*/
	public String getPass()
	{
		return pass;
	}
	public void setPass(String pass)
	{
		this.pass = pass;
	}
}
