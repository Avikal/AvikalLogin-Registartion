
package com.example.dghjewlers.model;

import java.util.ArrayList;
import java.util.List;


import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.content.Context;


public class UserFunctions {
	
	private JSONParser jsonParser;
	
	private static String loginURL = "http://www.sigmamtech.com/DoctorApi/api.php";
	private static String registerURL = "http://www.sigmamtech.com/DoctorApi/api.php";
	private static String patientURL = "http://www.sigmamtech.com/DoctorApi/api.php";
	private static String login_tag = "login";
	private static String register_tag = "register";
	private static String update_tag = "update";
	private static String view_tag = "view";
	
	private static String paitent_tag = "get_patients";
	// constructor
	public UserFunctions(){
		jsonParser = new JSONParser();
	}
	
	/**
	 * function make Login Request
	 * @param email
	 * @param password
	 * */
	public JSONObject loginUser(String email, String password){
		// Building Parameters
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("tag", login_tag));
		params.add(new BasicNameValuePair("email", email));
		params.add(new BasicNameValuePair("password", password));
		JSONObject json = jsonParser.getJSONFromUrl(loginURL, params);
		// return json
		// Log.e("JSON", json.toString());
		return json;
	}
	public JSONObject viewUser(String email)
	{
		List<NameValuePair> param = new ArrayList<NameValuePair>();
		param.add(new BasicNameValuePair("tag", "view"));
		param.add(new BasicNameValuePair("email", email));
		
		JSONObject json = jsonParser.getJSONFromUrl(loginURL, param);
		return json;
	}
	/**
	 * function make Login Request
	 * @param name
	 * @param email
	 * @param password
	 * */
	public JSONObject registerUser(String first_name, String last_name, String email, String password,
			String userPhone,String userProffesion, String userAdd, String userDes, String image_str){
		// Building Parameters
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("tag", register_tag));
		
		params.add(new BasicNameValuePair("first_name", first_name));
		params.add(new BasicNameValuePair("last_name", last_name));
		params.add(new BasicNameValuePair("email", email));
		params.add(new BasicNameValuePair("password", password));
		params.add(new BasicNameValuePair("phone", userPhone));
		params.add(new BasicNameValuePair("proffession", userProffesion));
		params.add(new BasicNameValuePair("address", userAdd));
		params.add(new BasicNameValuePair("discription", userDes));
		params.add(new BasicNameValuePair("image", image_str));
		// getting JSON Object
		JSONObject json = jsonParser.getJSONFromUrl(registerURL, params);
		// return json
		return json;
	}
	
	
	public JSONObject updateUser(String name, String email)
	{
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("tag", update_tag));
		params.add(new BasicNameValuePair("name", name));
		params.add(new BasicNameValuePair("email", email));
		
		JSONObject json = jsonParser.getJSONFromUrl(loginURL, params);
		
		return json;
		
	}
	/*public JSONObject viewUser(String email)
	{
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("tag", view_tag));
		JSONObject json = jsonParser.getJSONFromUrl(loginURL, params);
		return json;
	}*/
	/**
	 * Function get Login status
	 * */
	public boolean isUserLoggedIn(Context context){
		DataBaseHelper db = new DataBaseHelper(context);
		int count = db.getRowCount();
		if(count > 0){
			// user logged in
			return true;
		}
		return false;
	}
	
	/**
	 * Function to logout user
	 * Reset Database
	 * */
	public boolean logoutUser(Context context){
		DataBaseHelper db = new DataBaseHelper(context);
		db.resetTables();
		return true;
	}
	
	public JSONObject getPatientList(String email)
	{
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("tag", paitent_tag));
		params.add(new BasicNameValuePair("email", email));
		JSONObject json = jsonParser.getJSONFromUrl(patientURL, params);
		return json;
	}
	
}
