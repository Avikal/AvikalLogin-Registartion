package com.example.dghjewlers.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class DataBaseHelper extends SQLiteOpenHelper {

	private static final int DATABASE_VERSION = 1;

	private static final String DATABASE_NAME = "dghjewler";

	private static final String TABLE_CUSTOMER = "customer_table";
	private static final String TABLE_OWNER = "owner_table";

	private static final String KEY_ID = "id";
	private static final String KEY_FULL_NAME = "full_name";
	private static final String KEY_FATHERNAME = "father_name";
	private static final String KEY_DATE = "date";
	private static final String KEY_ADDRESS = "address";
	private static final String KEY_VILLAGE = "village";
	private static final String KEY_PHONE = "phone";
	private static final String KEY_AMOUNT = "amount";
	private static final String KEY_ITEM = "item";
	private static final String KEY_WEIGHT = "weight";
	private static final String KEY_DESCRPTION = "descrption";
	private static final String KEY_IMAGE = "image";

	private static String KEY_UID = "uid";
	private static String KEY_FNAME = "first_name";
	private static String KEY_LNAME = "last_name";
	private static String KEY_EMAIL = "email";
	private static String KEY_PASSWORD = "password";
	private static String KEY_OWNER_PHONE = "phone";
	// private static final String KEY_NAME = "name";
	// private static final String KEY_PHONE = "phone";
	// private static final String KEY_EMAIL = "email";
	// private static final String KEY_PASS = "pass";
	// private static final String KEY_UID = "uid";
	// private static final String KEY_CREATED_AT = "created_at";
	// private static final String KEY_NEW_EMAIL = "newemail";
	String newEmail;
	Context context;

	public DataBaseHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
		this.context = context;
	}

	public DataBaseHelper open() throws SQLException {
		SQLiteDatabase db = this.getReadableDatabase();
		return this;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		String CREATE_OWNER_TABLE = "CREATE TABLE " + TABLE_OWNER + "("
				+ KEY_UID + " INTEGER PRIMARY KEY," + KEY_FNAME + " TEXT,"
				+ KEY_LNAME + " TEXT," + KEY_EMAIL + " TEXT," + KEY_PASSWORD
				+ " TEXT," + KEY_OWNER_PHONE + " TEXT" + ")";

		String CREATE_LOGIN_TABLE = "CREATE TABLE " + TABLE_CUSTOMER + "("
				+ KEY_ID + " INTEGER PRIMARY KEY," + KEY_FULL_NAME + " TEXT,"
				+ KEY_FATHERNAME + " TEXT," + KEY_DATE + " TEXT," + KEY_ADDRESS
				+ " TEXT," + KEY_VILLAGE + " TEXT," + KEY_PHONE + " TEXT,"
				+ KEY_AMOUNT + " TEXT," + KEY_ITEM + " TEXT," + KEY_WEIGHT
				+ " TEXT," + KEY_DESCRPTION + " TEXT," + KEY_IMAGE + " BLOB"
				+ ")";
		// String CREATE_LOGIN_TABLE = "CREATE TABLE " + TABLE_LOGIN + "("
		// + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
		// + KEY_EMAIL + " TEXT UNIQUE," + KEY_UID + " TEXT,"
		// + KEY_CREATED_AT + " TEXT" + ")";
		// String CREATE_ACCOUNTS_TABLE =
		// "CREATE TABLE "+TABLE_LOGIN+"(KEY_ID INTEGER PRIMARY KEY,KEY_NAME TEXT,KEY_EMAIL TEXT,KEY_PASS TEXT,KEY_PHONE TEXT,KEY_PROFFESION TEXT,KEY_ADDRESS TEXT,KEY_DESCRIPTION TEXT);";
		db.execSQL(CREATE_LOGIN_TABLE);
		db.execSQL(CREATE_OWNER_TABLE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXIST " + TABLE_CUSTOMER);
		onCreate(db);
	}

	/**
	 * Storing user details in database
	 * */
	public long addUser(String Fullname, String Fathername, String date,
			String address, String village, String phone, String amount,
			String item, String weight, String description, byte[] imageByte) {
		// SQLiteDatabase db = this.getWritableDatabase();
		long d = 0;
		SQLiteDatabase db = this.getWritableDatabase();
		// Cursor cursor = db.query("login_table", null, " first_name=?",
		// new String[] { email }, null, null, null);

		ContentValues values = new ContentValues();
		// if (cursor.getCount() < 1) {
		values.put(KEY_FULL_NAME, Fullname); // Name
		values.put(KEY_FATHERNAME, Fathername);
		values.put(KEY_DATE, date); // EmailL
		values.put(KEY_ADDRESS, address); // Password
		values.put(KEY_VILLAGE, village);
		values.put(KEY_PHONE, phone);
		values.put(KEY_AMOUNT, amount);
		values.put(KEY_ITEM, item);
		values.put(KEY_WEIGHT, weight);
		values.put(KEY_DESCRPTION, description);
		values.put(KEY_IMAGE, imageByte);
		// Inserting Row
		d = db.insert(TABLE_CUSTOMER, null, values);
		db.close(); // Closing database connection
		// }
		return d;
	}

	public long addOwner(String userFName, String userLname, String userEmail,
			String userPass, String userPhone) {
		// SQLiteDatabase db = this.getWritableDatabase();
		long d = 0;
		SQLiteDatabase db = this.getWritableDatabase();
		// Cursor cursor = db.query("login_table", null, " first_name=?",
		// new String[] { email }, null, null, null);

		ContentValues values = new ContentValues();
		// if (cursor.getCount() < 1) {
		values.put(KEY_FNAME, userFName); // Name
		values.put(KEY_LNAME, userLname);
		values.put(KEY_EMAIL, userEmail); // EmailL
		values.put(KEY_PASSWORD, userPass); // Password
		values.put(KEY_OWNER_PHONE, userPhone);

		// Inserting Row
		d = db.insert(TABLE_OWNER, null, values);
		db.close(); // Closing database connection
		// }
		return d;
	}

	public List<SetGetMethod> getCustomerData() {
		List<SetGetMethod> cust_data = new ArrayList<SetGetMethod>();

		String selectQuery = "SELECT * FROM " + TABLE_CUSTOMER;

		SQLiteDatabase database = this.getWritableDatabase();

		Cursor cursor = database.rawQuery(selectQuery, null);

		if (cursor.moveToFirst()) {
			do {
				SetGetMethod customer = new SetGetMethod();
				customer.setId(Integer.parseInt(cursor.getString(0)));
				customer.setFullName(cursor.getString(1));
				customer.setFatherName(cursor.getString(2));

				customer.setDate(cursor.getString(3));
				customer.setAddress(cursor.getString(4));

				customer.setVillage(cursor.getString(5));
				customer.setMobile(cursor.getString(6));
				customer.setAmount(cursor.getString(7));
				customer.setitemType(cursor.getString(8));
				customer.setWeight(cursor.getString(9));
				customer.setDescription(cursor.getString(10));
				customer.setImage(cursor.getBlob(11));
				cust_data.add(customer);

			} while (cursor.moveToNext());
		}

		return cust_data;
	}

	public List<SetGetMethod> getSubjectName() {
		List<SetGetMethod> subject_name = new ArrayList<SetGetMethod>();

		String selectQuery = "SELECT * FROM " + TABLE_CUSTOMER;

		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);

		if (cursor.moveToFirst()) {
			do {
				SetGetMethod subject = new SetGetMethod();
				subject.setId(Integer.parseInt(cursor.getString(0)));
				subject.setFullName(cursor.getString(1));
				subject.setFatherName(cursor.getString(2));

				subject.setDate(cursor.getString(3));
				subject.setAddress(cursor.getString(4));

				subject.setVillage(cursor.getString(5));
				subject.setMobile(cursor.getString(6));
				subject.setAmount(cursor.getString(7));
				subject.setitemType(cursor.getString(8));
				subject.setWeight(cursor.getString(9));
				subject.setDescription(cursor.getString(10));
				subject.setImage(cursor.getBlob(11));
				subject_name.add(subject);
			} while (cursor.moveToNext());
		}
		return subject_name;
	}

	// public long addUser(Person person)
	// {
	// long d = 0;
	// SQLiteDatabase db = this.getWritableDatabase();
	// Cursor cursor=db.query("login_table", null, " name=?", new
	// String[]{person.getEmail()}, null, null, null);
	// ContentValues values = new ContentValues();
	// if(cursor.getCount()<1)
	// {
	// values.put(KEY_NAME, person.getUsername());
	// values.put(KEY_PHONE, person.getPhoneNo());
	// values.put(KEY_EMAIL, person.getEmail());
	// values.put(KEY_PASS, person.getPass());
	// String name = person.getUsername();
	// Toast.makeText(context, name, 10).show();
	//
	// d = db.insert(TABLE_LOGIN, null, values);
	// db.close();
	// }
	//
	// return d;
	// }
	public long updateUser(Person person, String newEmail) {
		long d = 0;
		SQLiteDatabase db = this.getWritableDatabase();
		this.newEmail = newEmail;
		// Cursor cursor=db.query("login_table", null, " name=?", new
		// String[]{person.getEmail()}, null, null, null);
		ContentValues values = new ContentValues();

		values.put(KEY_FULL_NAME, person.getUsername());
		// values.put(KEY_PHONE, person.getPhoneNo());
		values.put(KEY_VILLAGE, this.newEmail);
		// values.put(KEY_PASS, person.getPass());
		String name = person.getUsername();
		Toast.makeText(context, name, 10).show();

		d = db.update(TABLE_CUSTOMER, values, KEY_FULL_NAME + " = ?",
				new String[] { String.valueOf(person.getEmail()) });
		db.close();

		return d;
	}

	public long updateCustomer(int cust_id, String Fullname, String Fathername,
			String date, String address, String village, String phone,
			String amount, String item, String weight, String description,
			byte[] imageByte) {
		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(KEY_FULL_NAME, Fullname); // Name
		values.put(KEY_FATHERNAME, Fathername);
		values.put(KEY_DATE, date); // EmailL
		values.put(KEY_ADDRESS, address); // Password
		values.put(KEY_VILLAGE, village);
		values.put(KEY_PHONE, phone);
		values.put(KEY_AMOUNT, amount);
		values.put(KEY_ITEM, item);
		values.put(KEY_WEIGHT, weight);
		values.put(KEY_DESCRPTION, description);
		values.put(KEY_IMAGE, imageByte);

		long d = db.update(TABLE_CUSTOMER, values, KEY_ID + " = ?",
				new String[] { String.valueOf(cust_id) });

		db.close();

		return d;

	}

	public String singleEntry(String userName) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.query("owner_table", null, " email=?",
				new String[] { userName }, null, null, null);
		if (cursor.getCount() < 1) {
			cursor.close();
			return "NOT EXIST";
		}
		cursor.moveToFirst();
		String password = cursor.getString(cursor.getColumnIndex("password"));
		cursor.close();
		return password;
	}

	public String singleName(String userName) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.query("owner_table", null, " name=?",
				new String[] { userName }, null, null, null);
		if (cursor.getCount() < 1) {
			cursor.close();
			return "Not Exist";
		}
		cursor.moveToFirst();
		String name = cursor.getString(cursor.getColumnIndex("name"));
		cursor.close();
		return name;
	}

	public String singleMobile(String userName) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.query("owner_table", null, " name=?",
				new String[] { userName }, null, null, null);
		if (cursor.getCount() < 1) {
			cursor.close();
			return "Not Exist";
		}

		cursor.moveToFirst();
		String mobile = cursor.getString(cursor.getColumnIndex("phone"));
		cursor.close();
		return mobile;
	}

	public String singleEmail(String userName) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.query("owner_table", null, " name=?",
				new String[] { userName }, null, null, null);
		if (cursor.getCount() < 1) {
			cursor.close();
			return "Not Exist";
		}
		cursor.moveToFirst();
		String email = cursor.getString(cursor.getColumnIndex("email"));
		cursor.close();
		return email;
	}

	public int getRowCount() {
		String countQuery = "SELECT  * FROM " + TABLE_CUSTOMER;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(countQuery, null);
		int rowCount = cursor.getCount();
		db.close();
		cursor.close();

		// return row count
		return rowCount;
	}

	/**
	 * Re crate database Delete all tables and create them again
	 * */
	public void resetTables() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(TABLE_CUSTOMER, null, null);
		db.close();
	}

	/**
	 * Getting user data from database
	 * */
	public HashMap<String, String> getUserDetails() {
		HashMap<String, String> user = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM " + TABLE_CUSTOMER;

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// Move to first row

		cursor.moveToFirst();
		if (cursor.getCount() > 0) {
			user.put("Fname", cursor.getString(1));
			user.put("Lname", cursor.getString(2));
			user.put("email", cursor.getString(3));
			user.put("password", cursor.getString(4));
			user.put("phone", cursor.getString(5));
			user.put("proffession", cursor.getString(6));
			user.put("address", cursor.getString(7));

		}
		cursor.close();
		db.close();
		// return user
		return user;
	}

	public void deleteUser() {
		SQLiteDatabase database = this.getWritableDatabase();

		database.delete(TABLE_CUSTOMER, null, null);
		// database.delete(TABLE_SUBJECT, null, null);

		database.close();

		Log.d("Delete", "Deletd all user info from sqlite");

	}

	public void deleteCustRow(int id) {
		SQLiteDatabase database = this.getWritableDatabase();
		String deleteQuery = TABLE_CUSTOMER + " WHERE ID = " + id;
		database.delete(deleteQuery, null, null);
		database.close();
	}
}
