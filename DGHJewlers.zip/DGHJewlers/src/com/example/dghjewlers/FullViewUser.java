package com.example.dghjewlers;

import java.io.ByteArrayInputStream;

import com.example.dghjewlers.model.DataBaseHelper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class FullViewUser extends Activity
{
	TextView cust_name, cust_father,cust_date, cust_address, cust_village, cust_mobile, cust_amount, cust_itemType,
	cust_weight,cust_description;
	ImageView cust_image;
	
	String str_name,str_father,str_date,str_address,str_village,str_mobile,str_amount,str_itemType,
	str_weight,str_description;
	
	byte[] image;
	
	int cust_id;
	Button updateData, deleteData;
	Bundle bundle;
	DataBaseHelper dataBase;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fullview_user);
		dataBase = new DataBaseHelper(getApplicationContext());
		bundle = getIntent().getExtras();
		updateData = (Button) findViewById(R.id.btn_update);
		deleteData = (Button) findViewById(R.id.btn_delete);
		cust_id = bundle.getInt("custId");
		str_name = bundle.getString("custFullName");
		str_father = bundle.getString("custFatherName");
		str_date = bundle.getString("custDate");
		str_address = bundle.getString("custAddress");
		str_village = bundle.getString("custVillage");
		str_mobile = bundle.getString("custMobile");
		str_amount = bundle.getString("custAmount");
		str_itemType = bundle.getString("custItemType");
		str_weight = bundle.getString("custWeight");
		str_description = bundle.getString("custDesription");
		image = bundle.getByteArray("custImage");
		
		cust_name = (TextView) findViewById(R.id.text_fullname);
		cust_father = (TextView) findViewById(R.id.text_fathername);
		cust_date = (TextView) findViewById(R.id.text_date);
		cust_address = (TextView) findViewById(R.id.text_address);
		cust_village = (TextView) findViewById(R.id.text_village);
		cust_mobile = (TextView) findViewById(R.id.text_mobile);
		cust_amount = (TextView) findViewById(R.id.text_amount);
		cust_weight = (TextView) findViewById(R.id.text_weight);
		cust_description = (TextView) findViewById(R.id.text_des);
		cust_itemType = (TextView) findViewById(R.id.text_item);
		
		cust_image = (ImageView) findViewById(R.id.customer_image);
		
		cust_name.setText(str_name);
		cust_father.setText(str_father);
		cust_date.setText(str_date);
		cust_address.setText(str_address);
		cust_village.setText(str_village);
		cust_mobile.setText(str_mobile);
		cust_amount.setText(str_amount);
		cust_itemType.setText(str_itemType);
		cust_weight.setText(str_weight);
		cust_description.setText(str_description);
		
		ByteArrayInputStream imageStream = new ByteArrayInputStream(image);
		Bitmap theImage = BitmapFactory.decodeStream(imageStream);
		
		cust_image.setImageBitmap(theImage);
	
		updateData.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent update = new Intent(FullViewUser.this,UpdateCustomer.class);
				update.putExtra("custId", cust_id);
				update.putExtra("custFullName", str_name);
				update.putExtra("custFatherName", str_father);
				update.putExtra("custDate", str_date);
				update.putExtra("custAddress", str_address);
				update.putExtra("custVillage", str_village);
				update.putExtra("custMobile", str_mobile);
				update.putExtra("custAmount", str_amount);
				update.putExtra("custItemType", str_itemType);
				update.putExtra("custWeight", str_weight);
				update.putExtra("custDesription", str_description);
				update.putExtra("custImage", image);
				startActivity(update);
				finish();
			}
		});
		deleteData.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dataBase.deleteCustRow(cust_id);
				Intent delete = new Intent(FullViewUser.this,ViewCustomer.class);
				startActivity(delete);
				finish();
			}
		});
		
	}
}
