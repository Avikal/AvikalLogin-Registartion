package com.example.dghjewlers;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dghjewlers.model.DataBaseHelper;
//import com.doctorappserver.model.NetworkCheckActivity;
import com.example.dghjewlers.model.SessionManager;

//import com.doctorappserver.model.UserFunctions;

public class LoginActivity extends Activity {
	Button login;
	EditText user_login, user_pass;
	String login_user, pass_user;
	DataBaseHelper dataBase;
	private static String KEY_SUCCESS = "SUCCESS";
	private static String KEY_ERROR = "error";
	private static String KEY_ERROR_MSG = "error_msg";
	private static String KEY_UID = "uid";
	private static String KEY_FNAME = "first_name";
	private static String KEY_LNAME = "last_name";
	private static String KEY_EMAIL = "email";
	private static String KEY_PASSWORD = "password";
	private static String KEY_PHONE = "phone";
	private static String KEY_PROFESSION = "proffession";
	private static String KEY_ADDRESS = "address";
	private static String KEY_DESCRIPTION = "discription";
	private static String KEY_CREATED_AT = "created_at";
	// public NetworkCheckActivity network;
	boolean isNetworkAvailable;
	TextView register_text;
	private SessionManager session;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_xml);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}
		session = new SessionManager(getApplicationContext());
		if (session.isLoggedIn()) {
			Intent intent = new Intent(LoginActivity.this, AddCustomer.class);
			startActivity(intent);
			finish();
		}
		// network = new NetworkCheckActivity(this);
		// isNetworkAvailable = network.isConnectingInternet();

		dataBase = new DataBaseHelper(this);
		dataBase = dataBase.open();
		//
		register_text = (TextView) findViewById(R.id.forgat_password);
		user_login = (EditText) findViewById(R.id.editTextLoginname);
		user_pass = (EditText) findViewById(R.id.editTextLoginPass);
		login = (Button) findViewById(R.id.user_login);

		register_text.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent registr = new Intent(LoginActivity.this,
						RegisterActivity.class);
				startActivity(registr);
				finish();
			}
		});
		login.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				login_user = user_login.getText().toString();
				pass_user = user_pass.getText().toString();

				Log.d("Button", "Login");
				// Toast.makeText(getApplicationContext(), login_user,
				// Toast.LENGTH_SHORT).show();

				String storePassword = dataBase.singleEntry(login_user);
				if (pass_user.equals(storePassword)) {

					session.setLogin(true);
					Intent intent = new Intent(LoginActivity.this,
							AddCustomer.class);
					intent.putExtra("login_user", login_user);
					startActivity(intent);
					Toast.makeText(LoginActivity.this,
							"Congrats: Login Successfull", Toast.LENGTH_LONG)
							.show();
					finish();
				} else {

					Toast.makeText(LoginActivity.this,
							"User Name or Password does not match",
							Toast.LENGTH_LONG).show();
					Intent intent = new Intent(LoginActivity.this,
							AddCustomer.class);

					startActivity(intent);
					finish();
				}

			}
		});
	}
}
