package com.example.dghjewlers;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.dghjeweler.model.CustomerListAdapter;
import com.example.dghjewlers.model.DataBaseHelper;
import com.example.dghjewlers.model.SetGetMethod;

public class ViewCustomer extends Activity
{
	ListView customer_list;
	DataBaseHelper database;
	CustomerListAdapter adapter;
	ArrayList<SetGetMethod> cust_list = new ArrayList<SetGetMethod>();
	
	
	int cust_id;
	String cust_fullname,cust_fathername,cust_date,cust_address,cust_village,cust_mobile,
	cust_amount,cust_itemType,cust_weight,cust_desription;
	byte[] image2;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customer_view);
		
		customer_list = (ListView) findViewById(R.id.sub_list);
		
		database = new DataBaseHelper(getApplicationContext());
		
		List<SetGetMethod> customer_data = database.getCustomerData();
		
		for(SetGetMethod cust : customer_data)
		{
			cust_list.add(cust);
			adapter = new CustomerListAdapter(ViewCustomer.this, cust_list);
			customer_list.setAdapter(adapter);
			
		}
		
		
		
		customer_list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				SetGetMethod picture = cust_list.get(position);
				cust_id = picture.getId();
				cust_fullname = picture.getFullName();
				cust_fathername = picture.getFatherName();
				cust_date = picture.getDate();
				cust_address = picture.getAddress();
				cust_village = picture.getVillage();
				cust_mobile = picture.getMobile();
				cust_amount = picture.getAmount();
				cust_itemType = picture.getitemType();
				cust_weight = picture.getWeight();
				cust_desription = picture.getDesription();
				image2 = picture.getImage();
				Intent intent = new Intent(getApplicationContext(), FullViewUser.class);
				intent.putExtra("custId", cust_id);
				intent.putExtra("custFullName", cust_fullname);
				intent.putExtra("custFatherName", cust_fathername);
				intent.putExtra("custDate", cust_date);
				intent.putExtra("custAddress", cust_address);
				intent.putExtra("custVillage", cust_village);
				intent.putExtra("custMobile", cust_mobile);
				intent.putExtra("custAmount", cust_amount);
				intent.putExtra("custItemType", cust_itemType);
				intent.putExtra("custWeight", cust_weight);
				intent.putExtra("custDesription", cust_desription);
				intent.putExtra("custImage", image2);
				
				startActivity(intent);
				finish();
				
			}
			
		});
	}
}
