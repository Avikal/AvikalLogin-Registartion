package com.example.dghjewlers;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;

import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dghjewlers.model.DataBaseHelper;

import com.example.dghjewlers.model.SessionManager;

public class RegisterActivity extends Activity {

	int REQUEST_CAMERA = 0, SELECT_FILE = 1;
	JSONObject jsonobject;
	JSONObject jsonObject;
	JSONArray jsonarray;
	ArrayList<HashMap<String, String>> arraylist;
	ProgressDialog mProgressDialog;
	EditText first_name, last_name, email, pass, phone, /* profession, */
	address, description;
	String userFName, userLname, userEmail, userPass, userPhone,
			userProfession, userAdd, userDescription;
	Button register;

	ImageView nav_back;
	public static String img_url = "http://sigmamtech.com/DoctorApi/uploads/";
	private String[] proffession = { "Select Your Proffession",
			"Heart specialties", "Eye specialties", "Arunachal Pradesh",
			"Dermatologist", " Pediatric Dermatologist",
			"Hair Transplant Surgeon", "Sexologist", "Dentist",
			"Dental Surgeon", "Physiotherapist", "Neuro Physiotherapist",
			" HIV Specialist", "Homeopath", "Asthma Specialist",
			"Cardiologist", "Gynaecologist", "Psychiatrist", "Ophthalmologist",
			" Physician ", "Plastic Surgery" };
	static Spinner proffession_list;
	String proffession_str;
	String verified_code;
	// JSON Response node names
	private static String KEY_SUCCESS = "SUCCESS";
	private static String KEY_ERROR = "error";
	private static String KEY_ERROR_MSG = "error_msg";
	private static String KEY_UID = "uid";
	private static String KEY_FNAME = "first_name";
	private static String KEY_LNAME = "last_name";
	private static String KEY_EMAIL = "email";
	private static String KEY_PASSWORD = "password";
	private static String KEY_PHONE = "phone";
	private static String KEY_PROFESSION = "proffession";
	private static String KEY_ADDRESS = "address";
	private static String KEY_DESCRIPTION = "discription";
	private static String KEY_CREATED_AT = "created_at";

	String url;
	// NetworkCheckActivity network_check;
	boolean isNetworkCheck;
	DataBaseHelper db;
	long d;
	SessionManager session;
	static String image_str;
	byte imageInByte1[];
	ImageView user_picture, user_picture1;
	private static final int CAMERA_REQUEST = 1;
	private static final int PICK_FROM_GALLERY = 2;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register_xml);
		db = new DataBaseHelper(getApplicationContext());
		// network_check = new NetworkCheckActivity(RegisterActivity.this);
		session = new SessionManager(getApplicationContext());
		// isNetworkCheck = network_check.isConnectingInternet();
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		// if (session.isLoggedIn()) {
		// Intent intent = new Intent(RegisterActivity.this,
		// MenuActivity.class);
		// startActivity(intent);
		// finish();
		// }

//		user_picture = (ImageView) findViewById(R.id.user_pic);
//		user_picture1 = (ImageView) findViewById(R.id.user_picture);
		first_name = (EditText) findViewById(R.id.editTextRegisterFname);
		last_name = (EditText) findViewById(R.id.editTextRegisterLname);
		phone = (EditText) findViewById(R.id.editTextRegisterPhone);
		email = (EditText) findViewById(R.id.editTextRegisterEmail);
		pass = (EditText) findViewById(R.id.editTextRegisterPass);

		register = (Button) findViewById(R.id.user_Submit);
		nav_back = (ImageView) findViewById(R.id.nav_back_register);

		userFName = first_name.getText().toString();
		userLname = last_name.getText().toString();
		userEmail = email.getText().toString();
		userPass = pass.getText().toString();
		userPhone = phone.getText().toString();

		register.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				userFName = first_name.getText().toString();
				userLname = last_name.getText().toString();
				userEmail = email.getText().toString();
				userPass = pass.getText().toString();
				userPhone = phone.getText().toString();

				// DataBaseHelper db = new
				// DataBaseHelper(getApplicationContext());

				Intent dashboard = new Intent(getApplicationContext(),
						AddCustomer.class);
				startActivity(dashboard);
				finish();

				long d = db.addOwner(userFName, userLname, userEmail, userPass,
						userPhone);

				if (d == -1) {
					Toast.makeText(getApplicationContext(),
							"Please Fill all information Correct", 500).show();
				} else {
					session.setLogin(true);
					Intent intent = new Intent(RegisterActivity.this,
							AddCustomer.class);
					intent.putExtra("login_user", userFName);
					startActivity(intent);
					Toast.makeText(getApplicationContext(), "Data Inserted", 5)
							.show();

					finish();
				}

			}
		});
		nav_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent back = new Intent(RegisterActivity.this,
						LoginActivity.class);
				startActivity(back);
				finish();
			}
		});
		TextView text_back = (TextView) findViewById(R.id.text_back_register);
		text_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(RegisterActivity.this,
						LoginActivity.class);

				startActivity(intent);
				finish();

			}
		});
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		Intent back = new Intent(RegisterActivity.this, LoginActivity.class);
		startActivity(back);
		finish();
	}

}
