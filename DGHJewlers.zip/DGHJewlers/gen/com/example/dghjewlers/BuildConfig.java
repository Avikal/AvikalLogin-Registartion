/** Automatically generated file. DO NOT MODIFY */
package com.example.dghjewlers;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}